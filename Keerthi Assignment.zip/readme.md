Assignment Title: Domain Test (React SSR)

Time:
3.5 hours

## Assumptions: 
 - I assumed I can use next.js for server side rendering for react.js 
 - I assumed I can use material-ui/styles for styling the components.


## Libraries:
```
"@material-ui/styles": "^4.9.0",
"next": "^9.2.1",
"react": "^16.12.0",
"react-dom": "^16.12.0",
"react-star-ratings": "^2.3.0",
```

## Challenges 
Working with localStorage with react hooks to persist state across refresh on server side rendering as a bit of a challenge at first. I overcame it with a `useLocalStorage` hook.

## Developer Notes 
Install dependencies:
```
yarn
```

Start development server:
```
yarn dev
```

Build for production:
```
yarn build
```

- Keerthi