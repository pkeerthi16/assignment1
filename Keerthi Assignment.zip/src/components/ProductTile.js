import React from 'react';
import { makeStyles } from '@material-ui/styles';
import LoveIconButton from './LoveIconButton';
import StarRatings from 'react-star-ratings';
import AddToCart from './AddToCart';

const useStyles = makeStyles({
    productTile: {
        flex: 3,
        flexGrow: 1,
        padding: 12,
        borderRight: 'solid grey 1px',
        borderBottom: 'solid grey 1px',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        fontFamily: 'Heebo',
        height: 'fit-content',
        // maxWidth: '25%',

    },
    divider: {
        height: 1,
        backgroundColor: 'grey'
    },
    titleSection: {
        display: 'flex',
        flexGrow: 1,
        width: '100%',
        flexWrap: 'wrap',
        marginBottom: 10,
        minHeight: 65
    },
    title: {
        flex: 1,
        width: '100%',
        fontSize: 16,
        flexGrow: 1,
        textDecoration: 'none',
        color: 'black',
        '& > h4': {
            padding: 0,
            margin: 0,
        }
    },
    brandName: {
        color: 'grey',
        fontSize: 12,
        fontWeight: 'lighter',
        margin: 0,
        '&:hover': {
            textDecoration: 'underline'
        }
    },
    imageWrapper: {
        padding: '7.5px 7.5px 16px',
        display: 'flex',
        justifyContent: 'center'
    },
    image: {
        height: 'auto',
        // minWidth: '94%'
        minWidth: '100%'
    },
    price: {
        fontWeight: 'lighter',
        fontSize: 22
    },
    details: {
        paddingTop: 15,
        borderTop: 'solid grey 1px'
    }
})

export default ({ product, addItem }) => {
    const {
        images: [{ base_url, primary }],
        list_price: { formatted_price: price },
        title,
        brand,
        url
    } = product;
    const classes = useStyles();
    return (
        <div className={classes.productTile}>
            <div className={classes.imageWrapper}>
                <a href={`https://www.target.com${url}`}><img className={classes.image} src={`${base_url}${primary}`} /></a>
            </div>
            <div className={classes.details}>
                <div className={classes.titleSection}>
                    <a className={classes.title} href={`https://www.target.com${url}`}>
                        <h4>{title}</h4>
                        <h5 className={classes.brandName}>{brand}</h5>
                    </a>
                    <LoveIconButton />
                    
                </div>
                
                <StarRatings
                    id={product.title}
                    rating={product.average_rating}
                    starRatedColor="rgb(255, 215, 0)"
                    numberOfStars={5}
                    name='rating'
                    starDimension='20'
                    starSpacing='3px'
                />
                <span>{` (${product.total_reviews})`}</span>
                <h3 className={classes.price}>{price}</h3>
                <AddToCart addItem={addItem} />
            </div>
        </div>
    )
}