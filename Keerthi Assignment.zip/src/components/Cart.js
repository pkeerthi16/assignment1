import React from 'react';
import { makeStyles } from '@material-ui/styles';

const useStyles = makeStyles({
    cartContainer: {
        display: 'flex',
        flex: 3,
        justifyContent: 'flex-start',
        flexDirection: 'column',
        padding: 20
    },
    heading: {
        textAlign: "center",
        marginTop: 0,
        backgroundColor: 'red',
        color: 'white',
        padding: 10
    },
    total: {
        fontWeight: 'bold',
        fontSize: 20
    },
    item: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        '& > h4': {
            flex: 11,
            flexGrow: 1,
            width: '100%',
            fontSize: 15,
            fontWeight: 'lighter'
        },
        '& > *': {
            margin: '0 5px 0'
        },
        '& > span': {
            fontWeight: 'bold'
        },
        '& > button': {
            border: 'none',
            backgroundColor: 'white',
            cursor: 'pointer',
            padding: 10,
            fontWeight: 'bolder',
            marginLeft: 'auto',
            fill: 'red',
            '&:hover': {
                opacity: 0.6
            }
        }
    },
    checkoutButton: {
        float: 'right',
        padding: 6,
        fontSize: 18,
        backgroundColor: 'red',
        borderRadius: 5,
        color: 'white',
        width: '30%',
        '&:hover': {
            opacity: 0.8
        }
    }
});

const Delete = () => <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24">
    <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z" />
    <path d="M0 0h24v24H0z" fill="none" />
</svg>;

const Item = ({ title, price, image, removeItem }) => {
    const classes = useStyles();
    return <div className={classes.item}>
        <img src={image} width="50px" />
        <h4>{title}</h4>
        <span>{price}</span>
        <button onClick={removeItem}><Delete /></button>
    </div>
};

export default ({ items = [], removeItem }) => {
    const classes = useStyles();
    return <div className={classes.cartContainer}>
        <h3 className={classes.heading}>Cart</h3>
        {
            items.map((item, index) => {
                const {
                    images: [{ base_url, primary }],
                    list_price: { formatted_price: price },
                    title,
                } = item;
                return <Item key={`${primary}${index}`} title={title} price={price} image={`${base_url}${primary}`} removeItem={() => removeItem(item)} />
            })
        }
        <h2 className={classes.total}>Total <span style={{ float: 'right' }}>{items.reduce((res, item) => {
            const {
                list_price: { price },
            } = item;
            return res + price;
        }, 0)}$</span></h2>
        { items.length > 0 && <button className={classes.checkoutButton}>Checkout</button> }
    </div>
};