import React from 'react';
import { makeStyles } from '@material-ui/styles';


const useStyles = makeStyles({
    addToCart: {
        width: '30%',
        backgroundColor: 'red',
        borderRadius: 5,
        border: 'none',
        color: 'white',
        padding: 8,
        cursor: 'pointer',
        '&:focus': {
            outline: 'none'
        },
        '&:hover': {
            opacity: 0.7
        },
        fontSize: 16
    },
})


export default ({ addItem }) => {
    const classes = useStyles();
    return (
        <button className={classes.addToCart} onClick={addItem}>Add to Cart + </button>
    )
}