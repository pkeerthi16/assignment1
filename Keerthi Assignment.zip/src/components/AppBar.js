import React from 'react';
import { withStyles } from '@material-ui/styles';


export default withStyles({
    nav: {
        padding: '5px 20px',
        backgroundColor: 'red',
        color: 'white',
        boxShadow: '1px 0px 5px black'
    }
})(({ classes }) => <nav className={classes.nav}><h1>Shop</h1></nav>)