import React from 'react';
import ProductTile from './ProductTile';
import { makeStyles } from '@material-ui/styles';

const useStyles = makeStyles({
    gridContainer: {
        display: 'flex',
        flexWrap: 'wrap',
        flex: 11,
        boxSizing: 'border-box',
        padding: 20,
    }
})

export default ({ products, addItem }) => {
    const classes = useStyles();
    return (
        <div className={classes.gridContainer}>
            {
                products.map(product => {
                    return <ProductTile key={product.dpci} product={product} addItem={() => addItem(product)} />
                })
            }
        </div>
    )
}