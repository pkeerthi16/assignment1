import data from '../data';
import ProductGrid from '../src/components/ProductGrid';
import { makeStyles } from '@material-ui/styles';
import Cart from '../src/components/Cart';
import useLocalStorage from '../src/hooks/useLocalStorage';
import AppBar from '../src/components/AppBar';

const useStyles = makeStyles({
    container: { 
        width: '100%', 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center',
        flexDirection: 'column'
    },
    heading: {
        fontSize: 45,
    },
    shoppingSection: {
        display: 'flex',
        flexDirection: 'row'
    }
})

export default function Index(props) {
    const classes = useStyles();
    const [items, setStorage] = useLocalStorage('cart', []);

    const addItem = (item) => {
        setStorage([...items, { index: items.length, ...item }])
    }

    const removeItem = (item) => {
        setStorage(() => items.filter(i => i.index !== item.index))
    }

    return (
        <>
        <AppBar />
        <div className={classes.container}>
            <h1 className={classes.heading}>Umbrellas</h1>
            <div className={classes.shoppingSection}>
                <ProductGrid products={data.search_response.items.Item} addItem={addItem} />
                <Cart items={items} removeItem={removeItem} />
            </div>
        </div>
        </>
    );
}
